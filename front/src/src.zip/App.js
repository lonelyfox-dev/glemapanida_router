import React from "react"
import Header from "./components/Header"
import AddCity from "./components/AddCity"
import Cities from "./components/Cities"
class App extends React.Component{
    constructor(props){
        super(props)
        this.state={
            cities:[

            ]
        }
        this.addCity=this.addCity.bind(this)
    }
    render(){
        return(<div>
            <Header title="Glemapanida"/>
            <main>
                <Cities cities={this.state.cities}/>
            </main>
            <aside>
                <AddCity onAdd={this.addCity}/>
            </aside>
        </div>)
    }
    addCity(city){
        const id = this.state.cities.length+1
        this.setState({cities:[...this.state.cities,{id,...city}]})
        console.log(city)
    }
}
export default App